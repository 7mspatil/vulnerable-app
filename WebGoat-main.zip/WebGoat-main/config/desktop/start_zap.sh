#!/bin/sh

/config/java-jdk/bin/java -jar /config/ZAP_2.15.0/zap-2.15.0.jar
